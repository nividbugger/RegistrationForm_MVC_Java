Nivedhitaa Ranganathan
PES2UG19CS268

to create a simple form using MVC in java connecting it to mysql database and using basic html and javascript for the front end.
Core logic written in Java on eclipse IDE.